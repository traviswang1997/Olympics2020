export default {
	apiGateway: {
		"invokeUrl": " https://6oi2o3vgla.execute-api.ap-southeast-2.amazonaws.com/subscription"
	},
	cognito: {
		"REGION": "ap-southeast-2",
    	"USER_POOL_ID": "ap-southeast-2_kP7ST0aVt",
    	"APP_CLIENT_ID": "7kdimof4u1a2sudosjt8hq8dfj"
	}

}